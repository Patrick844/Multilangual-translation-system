# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html
import os
import sys
from unittest.mock import Mock
sys.path.insert(0, os.path.abspath('../..'))

MOCK_MODULES = ['fasttext','dotenv']
sys.modules.update((mod_name, Mock()) for mod_name in MOCK_MODULES)
# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'LingoWiz'
copyright = '2024, Patrick Saadde'
author = 'Patrick Saadde'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = []

templates_path = ['_templates']
exclude_patterns = []


html_baseurl = "https://patrick844.github.io/Multilangual-translation-system/"

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'alabaster'
html_static_path = ['_static']

extensions = [
    'sphinx.ext.autodoc',  # Extract documentation from docstrings
    'sphinx.ext.napoleon',  # Support for Google and NumPy docstring styles
    'sphinx.ext.viewcode',  # Add links to source code
]

html_theme = 'sphinx_rtd_theme'  # Use Read The Docs theme